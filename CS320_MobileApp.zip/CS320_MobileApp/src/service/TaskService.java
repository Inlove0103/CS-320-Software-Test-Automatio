package service;

import model.Task;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
	private final Map<String, Task> taskMap = new HashMap<>();

    public void addTask(Task task) {
        if (task == null || taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Invalid or duplicate task");
        }
        taskMap.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        taskMap.remove(taskId);
    }

    public void updateName(String taskId, String newName) {
        Task task = taskMap.get(taskId);
        if (task != null) {
            task.setName(newName);
        } else {
            throw new IllegalArgumentException("Task not found");
        }
    }

    public void updateDescription(String taskId, String newDescription) {
        Task task = taskMap.get(taskId);
        if (task != null) {
            task.setDescription(newDescription);
        } else {
            throw new IllegalArgumentException("Task not found");
        }
    }
}

