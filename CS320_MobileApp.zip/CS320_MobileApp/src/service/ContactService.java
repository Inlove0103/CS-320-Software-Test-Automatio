package service;

import model.Contact;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
	private final Map<String, Contact> contactMap = new HashMap<>();
	
	public void addContact(Contact contact) {
		if (contact == null || contactMap.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Invalid or duplicate contact");
        }
        contactMap.put(contact.getContactId(), contact);
    }

    public void deleteContact(String contactId) {
        if (!contactMap.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contactMap.remove(contactId);
    }

    public void updateFirstName(String contactId, String newFirstName) {
        Contact contact = contactMap.get(contactId);
        if (contact != null) {
            contact.setFirstName(newFirstName);
        } else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    public void updateLastName(String contactId, String newLastName) {
        Contact contact = contactMap.get(contactId);
        if (contact != null) {
            contact.setLastName(newLastName);
        } else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    public void updatePhone(String contactId, String newPhone) {
        Contact contact = contactMap.get(contactId);
        if (contact != null) {
            contact.setPhone(newPhone);
        } else {
            throw new IllegalArgumentException("Contact not found");
        }
    }

    public void updateAddress(String contactId, String newAddress) {
        Contact contact = contactMap.get(contactId);
        if (contact != null) {
            contact.setAddress(newAddress);
        } else {
            throw new IllegalArgumentException("Contact not found");
        }
    }
}

