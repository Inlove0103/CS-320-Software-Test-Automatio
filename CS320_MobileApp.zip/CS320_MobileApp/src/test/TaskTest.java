package test;

import model.Task;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
 

public class TaskTest {

	@Test
    public void testValidTaskCreation() {
        Task task = new Task("001", "Buy groceries", "Pick up milk, eggs, and bread");
        Assertions.assertEquals("001", task.getTaskId());
        Assertions.assertEquals("Buy groceries", task.getName());
        Assertions.assertEquals("Pick up milk, eggs, and bread", task.getDescription());
    }

    @Test
    public void testTaskIdTooLongThrowsException() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Clean", "Clean the apartment");
        });
    }

    @Test
    public void testNameTooLongThrowsException() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("002", "This name is way too long for validation", "Desc");
        });
    }

    @Test
    public void testDescriptionTooLongThrowsException() {
        String longDescription = "This description is far too long for a task and should throw an error due to its excessive length.";
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("003", "Valid name", longDescription);
        });
    }

    @Test
    public void testSetNameSuccessfully() {
        Task task = new Task("004", "Read", "Finish reading book");
        task.setName("Study");
        Assertions.assertEquals("Study", task.getName());
    }

    @Test
    public void testSetDescriptionWithNullThrowsException() {
        Task task = new Task("005", "Walk", "Evening walk");
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
    }
}
