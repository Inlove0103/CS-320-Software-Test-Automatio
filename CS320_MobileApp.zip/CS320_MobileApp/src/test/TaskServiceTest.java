package test;

import model.Tesk;
import service.TaskService;
import org.junit.jupiter.api.Assertions;
import org. junit.jupiter.api.Test;

public class TaskServiceTest {

	@Test
    public void testAddValidTask() {
        TaskService service = new TaskService();
        Task task = new Task("001", "Laundry", "Do laundry this weekend");
        service.addTask(task);
        // No assertion needed—success means no exception was thrown
    }

    @Test
    public void testAddDuplicateTaskThrowsException() {
        TaskService service = new TaskService();
        Task task1 = new Task("001", "Laundry", "Do laundry this weekend");
        Task task2 = new Task("001", "Dishes", "Do dishes tonight");
        service.addTask(task1);
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    public void testDeleteTaskSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("002", "Clean", "Clean the kitchen");
        service.addTask(task);
        service.deleteTask("002");
    }

    @Test
    public void testDeleteNonexistentTaskThrowsException() {
        TaskService service = new TaskService();
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("missing");
        });
    }

    @Test
    public void testUpdateNameSuccessfully() {
        TaskService service = new TaskService();
        Task task = new Task("003", "Shop", "Buy groceries");
        service.addTask(task);
        service.updateName("003", "Shopping");
        Assertions.assertEquals("Shopping", task.getName());
    }

    @Test
    public void testUpdateDescriptionWithInvalidValueThrowsException() {
        TaskService service = new TaskService();
        Task task = new Task("004", "Call", "Call mom tonight");
        service.addTask(task);
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("004", null);
        });
    }
}

