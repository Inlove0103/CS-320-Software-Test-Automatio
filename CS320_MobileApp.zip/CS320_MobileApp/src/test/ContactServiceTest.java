package test;

import model.Contact;
import service.ContactService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

	@Test
    public void testAddValidContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "June", "Smooth", "1234567890", "123 Main St");
        service.addContact(contact);
    }

    @Test
    public void testAddDuplicateContactThrowsException() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("001", "June", "Smooth", "1234567890", "123 Main St");
        Contact contact2 = new Contact("001", "Bob", "Jones", "0987654321", "456 Elm St");
        service.addContact(contact1);
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteExistingContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "June", "Smooth", "1234567890", "123 Main St");
        service.addContact(contact);
        service.deleteContact("001");
    }

    @Test
    public void testDeleteNonexistentContactThrowsException() {
        ContactService service = new ContactService();
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("invalid");
        });
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "June", "Smooth", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateFirstName("001", "Eve");
        Assertions.assertEquals("Eve", contact.getFirstName());
    }

    @Test
    public void testUpdatePhoneWithInvalidValue() {
        ContactService service = new ContactService();
        Contact contact = new Contact("001", "June", "Smooth", "1234567890", "123 Main St");
        service.addContact(contact);
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("001", "badphone");
        });
    }
}
