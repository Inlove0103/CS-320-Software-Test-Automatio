package test;

import model.Appointment;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // 100 seconds in the future
        Appointment appointment = new Appointment("001", futureDate, "Dentist appointment");
        Assertions.assertEquals("001", appointment.getAppointmentId());
        Assertions.assertEquals(futureDate, appointment.getAppointmentDate());
        Assertions.assertEquals("Dentist appointment", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdTooLongThrowsException() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Checkup");
        });
    }

    @Test
    public void testNullDateThrowsException() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("002", null, "Meeting");
        });
    }

    @Test
    public void testDateInPastThrowsException() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); // 100 seconds ago
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("003", pastDate, "Past event");
        });
    }

    @Test
    public void testDescriptionTooLongThrowsException() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        String longDescription = "This description is way too long and should definitely trigger an exception because it exceeds fifty characters.";
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("004", futureDate, longDescription);
        });
    }
}

