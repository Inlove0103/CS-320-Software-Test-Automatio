package test;

import model.Appointment;
import service.AppointmentService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions; 

import java.util.Date;

public class AppointmentServiceTest {
	
	@Test
    public void testAddValidAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("001", new Date(System.currentTimeMillis() + 100000), "Doctor visit");
        service.addAppointment(appointment);

        // No assertion needed unless you expose internal map or add a retrieval method.
        
        // If no exception is thrown, test passes.
    }

    @Test
    public void testAddDuplicateAppointmentThrowsException() {
        AppointmentService service = new AppointmentService();
        Appointment appointment1 = new Appointment("001", new Date(System.currentTimeMillis() + 100000), "Dentist");
        Appointment appointment2 = new Appointment("001", new Date(System.currentTimeMillis() + 200000), "Therapy");

        service.addAppointment(appointment1);

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteAppointmentSuccessfully() {
        AppointmentService service = new AppointmentService();
        Appointment appointment = new Appointment("001", new Date(System.currentTimeMillis() + 100000), "Meeting");
        service.addAppointment(appointment);
        service.deleteAppointment("001");
        // If no exception is thrown, deletion worked
    }

    @Test
    public void testDeleteNonExistentAppointmentThrowsException() {
        AppointmentService service = new AppointmentService();

        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("nonexistent");
        });
    }
}
